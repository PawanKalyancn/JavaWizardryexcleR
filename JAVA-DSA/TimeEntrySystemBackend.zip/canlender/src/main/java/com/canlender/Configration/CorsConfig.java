package com.canlender.Configration;

public class CorsConfig {

}
